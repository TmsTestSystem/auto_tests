from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import Dict
from typing import cast

if TYPE_CHECKING:
  from ..models.passport import Passport





T = TypeVar("T", bound="Person")


@_attrs_define
class Person:
    """ 
        Attributes:
            firstname (str):
            lastname (str):
            middlename (str):
            passport (Passport):
     """

    firstname: str
    lastname: str
    middlename: str
    passport: 'Passport'
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from ..models.passport import Passport
        firstname = self.firstname

        lastname = self.lastname

        middlename = self.middlename

        passport = self.passport.to_dict()


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "firstname": firstname,
            "lastname": lastname,
            "middlename": middlename,
            "passport": passport,
        })

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.passport import Passport
        d = src_dict.copy()
        firstname = d.pop("firstname")

        lastname = d.pop("lastname")

        middlename = d.pop("middlename")

        passport = Passport.from_dict(d.pop("passport"))




        person = cls(
            firstname=firstname,
            lastname=lastname,
            middlename=middlename,
            passport=passport,
        )


        person.additional_properties = d
        return person

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
