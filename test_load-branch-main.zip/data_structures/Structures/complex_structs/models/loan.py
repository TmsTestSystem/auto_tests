from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import Dict
from typing import cast, List
from typing import cast

if TYPE_CHECKING:
  from ..models.money import Money
  from ..models.person import Person
  from ..models.object_ import Object





T = TypeVar("T", bound="Loan")


@_attrs_define
class Loan:
    """ Объект заявка

        Attributes:
            amount_requested (Money): Деньги
            auto (Object): Объект кредита (авто, в том числе БУ)
            co_issuers (List['Person']): Созаемщики
            initial_payment (Money): Деньги
            issuer (Person):
     """

    amount_requested: 'Money'
    auto: 'Object'
    co_issuers: List['Person']
    initial_payment: 'Money'
    issuer: 'Person'
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from ..models.money import Money
        from ..models.person import Person
        from ..models.object_ import Object
        amount_requested = self.amount_requested.to_dict()

        auto = self.auto.to_dict()

        co_issuers = []
        for co_issuers_item_data in self.co_issuers:
            co_issuers_item = co_issuers_item_data.to_dict()
            co_issuers.append(co_issuers_item)



        initial_payment = self.initial_payment.to_dict()

        issuer = self.issuer.to_dict()


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "amount_requested": amount_requested,
            "auto": auto,
            "co_issuers": co_issuers,
            "initial_payment": initial_payment,
            "issuer": issuer,
        })

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.money import Money
        from ..models.person import Person
        from ..models.object_ import Object
        d = src_dict.copy()
        amount_requested = Money.from_dict(d.pop("amount_requested"))




        auto = Object.from_dict(d.pop("auto"))




        co_issuers = []
        _co_issuers = d.pop("co_issuers")
        for co_issuers_item_data in (_co_issuers):
            co_issuers_item = Person.from_dict(co_issuers_item_data)



            co_issuers.append(co_issuers_item)


        initial_payment = Money.from_dict(d.pop("initial_payment"))




        issuer = Person.from_dict(d.pop("issuer"))




        loan = cls(
            amount_requested=amount_requested,
            auto=auto,
            co_issuers=co_issuers,
            initial_payment=initial_payment,
            issuer=issuer,
        )


        loan.additional_properties = d
        return loan

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
