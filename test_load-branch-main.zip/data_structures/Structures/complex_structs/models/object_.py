from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import Dict
from ..types import UNSET, Unset
from typing import cast
from typing import Union

if TYPE_CHECKING:
  from ..models.person import Person





T = TypeVar("T", bound="Object")


@_attrs_define
class Object:
    """ Объект кредита (авто, в том числе БУ)

        Attributes:
            VIN (str):
            is_new (bool):
            is_used (bool):
            owner (Union[Unset, Person]):
     """

    VIN: str
    is_new: bool
    is_used: bool
    owner: Union[Unset, 'Person'] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from ..models.person import Person
        VIN = self.VIN

        is_new = self.is_new

        is_used = self.is_used

        owner: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.owner, Unset):
            owner = self.owner.to_dict()


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "VIN": VIN,
            "is_new": is_new,
            "is_used": is_used,
        })
        if owner is not UNSET:
            field_dict["owner"] = owner

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.person import Person
        d = src_dict.copy()
        VIN = d.pop("VIN")

        is_new = d.pop("is_new")

        is_used = d.pop("is_used")

        _owner = d.pop("owner", UNSET)
        owner: Union[Unset, Person]
        if isinstance(_owner,  Unset):
            owner = UNSET
        else:
            owner = Person.from_dict(_owner)




        object_ = cls(
            VIN=VIN,
            is_new=is_new,
            is_used=is_used,
            owner=owner,
        )


        object_.additional_properties = d
        return object_

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
