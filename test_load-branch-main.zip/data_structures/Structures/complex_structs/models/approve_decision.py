from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import Dict
from typing import cast, List
from typing import cast

if TYPE_CHECKING:
  from ..models.payment import Payment
  from ..models.currency import Currency





T = TypeVar("T", bound="ApproveDecision")


@_attrs_define
class ApproveDecision:
    """ 
        Attributes:
            currencies (List['Currency']): Валюты на момент расчета
            loan_rate (float): Ставка по кредиту
            payments (List['Payment']): График платежей
            total (float): Общая сумма платежей
     """

    currencies: List['Currency']
    loan_rate: float
    payments: List['Payment']
    total: float
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from ..models.payment import Payment
        from ..models.currency import Currency
        currencies = []
        for currencies_item_data in self.currencies:
            currencies_item = currencies_item_data.to_dict()
            currencies.append(currencies_item)



        loan_rate = self.loan_rate

        payments = []
        for payments_item_data in self.payments:
            payments_item = payments_item_data.to_dict()
            payments.append(payments_item)



        total = self.total


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "currencies": currencies,
            "loan_rate": loan_rate,
            "payments": payments,
            "total": total,
        })

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.payment import Payment
        from ..models.currency import Currency
        d = src_dict.copy()
        currencies = []
        _currencies = d.pop("currencies")
        for currencies_item_data in (_currencies):
            currencies_item = Currency.from_dict(currencies_item_data)



            currencies.append(currencies_item)


        loan_rate = d.pop("loan_rate")

        payments = []
        _payments = d.pop("payments")
        for payments_item_data in (_payments):
            payments_item = Payment.from_dict(payments_item_data)



            payments.append(payments_item)


        total = d.pop("total")

        approve_decision = cls(
            currencies=currencies,
            loan_rate=loan_rate,
            payments=payments,
            total=total,
        )


        approve_decision.additional_properties = d
        return approve_decision

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
