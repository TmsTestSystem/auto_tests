from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import Dict
from typing import cast

if TYPE_CHECKING:
  from ..models.money import Money
  from ..models.rate import Rate





T = TypeVar("T", bound="ParamsForCalculator")


@_attrs_define
class ParamsForCalculator:
    """ 
        Attributes:
            initial (Money): Деньги
            months (int):
            rate (Rate):
            requested (Money): Деньги
     """

    initial: 'Money'
    months: int
    rate: 'Rate'
    requested: 'Money'
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from ..models.money import Money
        from ..models.rate import Rate
        initial = self.initial.to_dict()

        months = self.months

        rate = self.rate.to_dict()

        requested = self.requested.to_dict()


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "initial": initial,
            "months": months,
            "rate": rate,
            "requested": requested,
        })

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.money import Money
        from ..models.rate import Rate
        d = src_dict.copy()
        initial = Money.from_dict(d.pop("initial"))




        months = d.pop("months")

        rate = Rate.from_dict(d.pop("rate"))




        requested = Money.from_dict(d.pop("requested"))




        params_for_calculator = cls(
            initial=initial,
            months=months,
            rate=rate,
            requested=requested,
        )


        params_for_calculator.additional_properties = d
        return params_for_calculator

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
