""" Contains all the data models used in inputs/outputs """

from .approve_decision import ApproveDecision
from .currency import Currency
from .decline_decision import DeclineDecision
from .loan import Loan
from .money import Money
from .object_ import Object
from .params_for_calculator import ParamsForCalculator
from .passport import Passport
from .payment import Payment
from .person import Person
from .rate import Rate

__all__ = (
    "ApproveDecision",
    "Currency",
    "DeclineDecision",
    "Loan",
    "Money",
    "Object",
    "ParamsForCalculator",
    "Passport",
    "Payment",
    "Person",
    "Rate",
)
