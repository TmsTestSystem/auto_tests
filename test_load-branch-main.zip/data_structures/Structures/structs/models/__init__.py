""" Contains all the data models used in inputs/outputs """

from .sum_numbers import SumNumbers

__all__ = (
    "SumNumbers",
)
