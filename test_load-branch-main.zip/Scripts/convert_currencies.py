import json
from data_structures.Structures.complex_structs.models.money import Money

def convert_to_rubles(currencies_json, money: Money) -> float:
    data = json.loads(currencies_json)
    print(f'#{money.currency_code} = #{data["Valute"][money.currency_code]}')
    currency = data["Valute"][money.currency_code]
    return money.value * currency['Value'] * (1 / currency['Nominal'])
    