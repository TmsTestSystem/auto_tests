
def log_print(val):
    print(val)
