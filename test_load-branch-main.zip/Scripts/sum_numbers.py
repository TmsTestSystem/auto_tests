from data_structures.Structures.structs.models.sum_numbers import SumNumbers

def sum_numbers(data: SumNumbers) -> int:
    return data.number_1 + data.number_2

