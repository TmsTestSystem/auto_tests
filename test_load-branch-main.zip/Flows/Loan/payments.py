
from data_structures.Structures.complex_structs.models.params_for_calculator import ParamsForCalculator
from data_structures.Structures.complex_structs.models.payment import Payment
from data_structures.Structures.complex_structs.models.money import Money
from datetime import date

def calculate_payments(pfc: ParamsForCalculator, rubs: float) -> list[Payment]:

    return [
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0)),
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0)),
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0)),
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0)),
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0)),
        Payment(date.today(), Money('RUB', 0), Money('RUB', 0))
    ]
