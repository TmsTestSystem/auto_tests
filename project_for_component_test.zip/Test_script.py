from typing import List, Dict, Optional, Union

def process_data(
    a: int,
    b: float,
    c: str,
    d: bool,
    e: List[int],
    f: Dict[str, Union[int, str]],
    g: Optional[complex] = None
) -> dict:

    total_sum = a + int(b)  # сложение int и приведённого float
    text_length = len(c)    # длина строки
    flag_result = d and (a > 0)  # логическая операция
    list_sum = sum(e) if e else 0  # сумма списка целых
    dict_keys_count = len(f)       # количество ключей в словаре
    complex_real = g.real if g is not None else 0.0  # получаем real часть комплексного числа

    return {
        "total_sum": total_sum,
        "text_length": text_length,
        "flag_result": flag_result,
        "list_sum": list_sum,
        "dict_keys_count": dict_keys_count,
        "complex_real": complex_real
    }

    print("Сумма a и целой части b:", total_sum)
    print("Длина строки c:", text_length)
    print("Результат логической операции (d и a > 0):", flag_result)
    print("Сумма элементов списка e:", list_sum)
    print("Количество ключей в словаре f:", dict_keys_count)
    print("Действительная часть комплексного числа g:", complex_real)